import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-info2',
  templateUrl: './other-info2.component.html',
  styleUrls: ['./other-info2.component.css']
})
export class OtherInfo2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
