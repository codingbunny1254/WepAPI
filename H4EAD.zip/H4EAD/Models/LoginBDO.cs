﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace H4EAD.Models
{
    public class LoginBDO
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
    }
}