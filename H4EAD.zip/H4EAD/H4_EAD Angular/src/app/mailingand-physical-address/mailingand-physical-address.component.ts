import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mailingand-physical-address',
  templateUrl: './mailingand-physical-address.component.html',
  styleUrls: ['./mailingand-physical-address.component.css']
})
export class MailingandPhysicalAddressComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
