import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-info1',
  templateUrl: './other-info1.component.html',
  styleUrls: ['./other-info1.component.css']
})
export class OtherInfo1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
