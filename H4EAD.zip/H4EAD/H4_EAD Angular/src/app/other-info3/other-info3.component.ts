import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-info3',
  templateUrl: './other-info3.component.html',
  styleUrls: ['./other-info3.component.css']
})
export class OtherInfo3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
